# LDDM-Projeto

## Nome do Projeto

Gestão pessoal

## Componentes do Time

- [Gabriel Vargas](https://github.com/GabrielVargasBS)
- [Mateus Leal](https://github.com/mateus123finn)
- [Nilson Deon](https://github.com/NilsonDeon)
- [Saulo de Moura](https://github.com/SauloMFreitas)


## Link para Download do Github

## Proposta de Desenvolvimento

1. Objetivo do App - o que é e para que serve
- Gerenciamento pessoal gamificado.
- aplicativo para planejamento pessoal focado para estudantes
2. Publico alvo do App - quem irá se beneficiar com a utilização do App
- estudantes no geral, mas focado em universitários
3. Principais funcionalidades
- gerenciamento de datas de atividades e provas, com notificações de aviso prévio
4. Rascunho das telas do App
   https://miro.com/welcomeonboard/QTZUTXp4NUF5czhRSXN4ck84d3FSM01md0t3YVpGdjA3ZVRZaG83dG43c2JjT21CWENXQ1N4T0VrRUdKNFpDQXwzNDU4NzY0NTMxMTIwNTU2NjYzfDI=?share_link_id=793407896614
